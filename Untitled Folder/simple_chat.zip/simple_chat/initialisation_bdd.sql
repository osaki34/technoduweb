CREATE TABLE msgs(id int primary key auto_increment, nom varchar(50), msg text);
